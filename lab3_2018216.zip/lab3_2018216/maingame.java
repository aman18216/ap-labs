import java.util.Scanner;
import java.util.ArrayList;
import java.util.Random;

class game{
	private final String username = "";

	public String getUsername() {
		return username;
	}
	public void displaygame() {
		System.out.println("welcome to the  guardians of galaxy");
		System.out.println("choose a option");
		System.out.println("1 )  new user");
		System.out.println("2 ) existing user ");
		System.out.println("3 ) exit");
	}
}
class user {
	private String username;

	public user(String username) {
		this.username = username;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	ArrayList<user> user1 = new ArrayList<user>();

	public void adduser(String username) {
		user1.add(new user(username));
	}
}

 class hero {
	protected  int xp;
	protected int hp;
	private final String name;
	private monster Monster;
	//protected int maxdamage;
	//protected int mindamage;
	protected double hitchance;

	public hero(int xp, int hp, String name) {
		// super(username);
		this.xp = xp;
		this.hp = hp;
		this.name = name;
	}

	public int getXp() {
		return xp;
	}

	public int getHp() {
		return hp;
	}

	public String getName() {
		return name;
	}

	public void herostypes() {
		ArrayList<hero> he = new ArrayList<hero>();
		//hero h1 = new hero(100, 0, "warrior");
		//.he.hero h2 = new hero(100, 0, "theif");
		//hero// h3 = new hero(100, 0, "mage");
		//hero h4 = new hero(100, 0, "healer");
		//he.add(h1);
		//he.add(h2);
		//he.add(h3);
		//he.add(h4);
		// System.out.print(h1);
	}
	public void setMonster(monster Monster) {
	    this.Monster = Monster;
	}
	public void decreasehp(int damage) {
		this.hp = getHp() - damage;
	}
	public  void attack(hero mn) {
	}
	public void attackdamage(monster m) {
		Random rand = new Random();
		//int damage   =(rand.nextDouble()< hitchance ? rand.nextInt(maxdamage - mindamage) + mindamage :0);
		//if (damage > 0) {
			//System.out.println(this.name + " " + damage+ m.getName() );
			//m.hp -= damage;
			//if (m .hp <1) {
			//	m.hp = 0;
			}
		//}
		//else {
			//System.out.println(this.name + "attack missed");
		//}
	//}
	public boolean isalive() {
		if (this.hp <0) {
			return true;
		}else {
			return false;
		}
	}
	
	public void defence() {
		
	}
}
abstract class warrorior extends hero{

	public warrorior(int xp, int hp, String name) {
		super(xp, hp, name);
		// TODO Auto-generated constructor stub
	}
	
}
abstract class theif extends hero{

	public theif(int xp, int hp, String name) {
		super(xp, hp, name);
		// TODO Auto-generated constructor stub
	}
	
}
abstract class mage extends hero{

	public mage(int xp, int hp, String name) {
		super(xp, hp, name);
		// TODO Auto-generated constructor stub
	}
	public void specialaatck(){
		
	}
	
}
abstract class healer extends hero{

	public healer(int xp, int hp, String name) {
		super(xp, hp, name);
		// TODO Auto-generated constructor stub
	}
	
}

class monster {
	private String name;
	protected int xp;
	protected int hp;

	public monster(String name, int xp, int hp) {
		super();
		this.name = name;
		this.xp = xp;
		this.hp = hp;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getXp() {
		return xp;
	}

	public void setXp(int xp) {
		this.xp = xp;
	}

	public int getHp() {
		return hp;
	}

	public void setHp(int hp) {
		this.hp = hp;
	}
	public void attack() {
		
	}
	ArrayList <monster> mun = new ArrayList<monster>();
	

}
class goblins extends monster{

	public goblins(String name, int xp, int hp) {
		super(name, xp, hp);
		// TODO Auto-generated constructor stub
	}
	
}
class zombies extends monster{

	public zombies(String name, int xp, int hp) {
		super(name, xp, hp);
		// TODO Auto-generated constructor stub
	}
	
}
class fiends extends monster{

	public fiends(String name, int xp, int hp) {
		super(name, xp, hp);
		// TODO Auto-generated constructor stub
	}
	
}
class lionflag extends monster{

	public lionflag(String name, int xp, int hp) {
		super(name, xp, hp);
		// TODO Auto-generated constructor stub
	}
	
}

public class maingame {
	public static void main(String args[]) {
		Scanner scan = new Scanner(System.in);
		game main = new game();
		user us = new user(null);
		hero her = new hero(0, 0, null);
		main.displaygame();
		for (int i = 0; i < 10; i++) {
			int t = scan.nextInt();
			if (t == 1) {
				System.out.println("enter username");
				String usr = scan.next();
				System.out.println("choose type of heros");
				System.out.println("1)" + " " + "warrior");
				System.out.println("2)" + " " + "thief");
				System.out.println("3)" + " " + "marge");
				System.out.println("4)" + " " + "healer");
				int un = scan.nextInt();
				if (un == 1) {
					System.out.print("user creation done" + " | ");
					System.out.print("username" + " " + usr + ".");
					System.out.print("hero type " + " " + "warrior");
					System.out.print("log into play the game");
					System.out.println("existing");
					main.displaygame();
					int urf = scan.nextInt();
					if (urf == 2) {
						System.out.println("enter a username");
						String ued = scan.next();
						if (ued.matches(usr)) {
							System.out.println("user found....logging in ");
							System.out.println("welcome " + usr);
							System.out.println("you are at the sarting location" + " " + "choodse path");
							Random rand  = new Random();
							int r1 = rand.nextInt(10);
							int r2 = rand.nextInt(10);
							int r3 = rand.nextInt(10);
							System.out.println("1)" + " " + "go to location "+r1);
							System.out.println("2)" + " " + "go to location "+r2);
							System.out.println("3)" + " " + "go to location "+r3);
							// System.out.println("4)"+" "+"go to location 1");
							System.out.println("enter -1 to exit");

						} else {
							System.out.println("user not found");
						}
						int ght = scan.nextInt();
						if (ght == 1) {
							System.out.println("moving to location 0 ");
							System.out.println("fight started . you fighting a level 1 monster");
							System.out.println("choose a fight option");
							System.out.println("1)" + " " + "attack");
							System.out.println("2)" + " " + "defence");
							int uht = scan.nextInt();
							if (uht == 1) {
								System.out.println("you choose to attack");
								//int kill = scan.nextInt();
								System.out.println("you attacked and infiliated by "+"10"+"damage the heros");
								int r = 100-10;
								System.out.println("your hp : 100 /100 "+ " : "+"monster hp :"+ r);
								System.out.println("monster attack");
								Random rand  = new Random();
								int un3  =(int) (0.25 * r);
								//System.out.println(un3);
								int lo = 1;
								int un2 = (int) (Math.random() * (un3 - lo)) + lo;
								System.out.println("monster attacked and indlicated by"+un2+"damage to you");
								int y  = 100 - un2;
								//her.sethp(y);
								System.out.println("your hp: "+y +"/100"+" "+" monster hp :"+r+"/100");
							if (uht == 2) {
									System.out.println("you choose to defence");
									System.out.println("monster attack");
									Random rand2  = new Random();
									int un32  =(int) (0.25 * r);
									//System.out.println(un3);
									int lo2 = 1;
									int un22 = (int) (Math.random() * (un32 - lo2)) + lo2;
									System.out.println("monster attacked and indlicated by"+un2+"damage to you");
									int y2  = (100 - un22) -3;
									//her.sethp(y);
									System.out.println("your hp: "+y2 +"/100"+" "+" monster hp :"+r+"/100");
									
							}
								System.out.println("choose a fight option");
								System.out.println("1)" + " " + "attack");
								System.out.println("2)" + " " + "defence");
								int yu =scan.nextInt();
								if (yu == 1) {
									System.out.println("you choose to attack");
									//int kill1 = scan.nextInt();
									System.out.println("you attacked and infiliated by "+10+"damage the heros");
									int r1 = r-10;
									System.out.println("your hp: "+y +"/100"+" "+" monster hp :"+r1+"/100");
									System.out.println("monster attack");
									Random rand1  = new Random();
									int un31  =(int) (0.25 * r1);
									//System.out.println(un3);
									int lo1 = 1;
									int un21 = (int) (Math.random() * (un31 - lo1)) + lo1;
									System.out.println("monster attacked and indlicated by"+un21+"damage to you");
									int y1  = y - un21;
									//her.sethp(y);
									System.out.println("your hp: "+y1 +"/100"+" "+" monster hp :"+r1+"/100");
									System.out.println("choose a fight option");
									System.out.println("1)" + " " + "attack");
									System.out.println("2)" + " " + "defence");
									int tuf = scan.nextInt();
									if (tuf== 1) {
										System.out.println("you choose to attack");
										//int kill1 = scan.nextInt();
										System.out.println("you attacked and infiliated by "+10+"damage the heros");
										int r11 = r1-10;
										System.out.println("your hp: "+y1 +"/100"+" "+" monster hp :"+r11+"/100");
										System.out.println("monster attack");
										Random rand11  = new Random();
										int un311  =(int) (0.25 * r11);
										//System.out.println(un3);
										int lo11 = 1;
										int un211 = (int) (Math.random() * (un311 - lo11)) + lo11;
										System.out.println("monster attacked and indlicated by"+un211+"damage to you");
										int y11  = y1 - un211;
										//her.sethp(y);
										System.out.println("your hp: "+y11 +"/100"+" "+" monster hp :"+r11+"/100");
										System.out.println("choose a fight option");
										System.out.println("1)" + " " + "attack");
										System.out.println("2)" + " " + "defence");
										System.out.println("3)" + " " + "special attack");
										int  ugh = scan.nextInt();
										if (ugh == 1) {
											
										}
										if (ugh == 2) {
											
										}
										if (ugh == 3) {
											System.out.println("special power activated");
											System.out.println("special power activated ");
											System.out.println("you attacked and infiliated by "+15+"damage the heros");
											int r111 = r11-15;
											System.out.println("your hp: "+y11 +"/100"+" "+" monster hp :"+r111+"/100");
											System.out.println("monster attack");
											Random rand111  = new Random();
											int un3111  =(int) (0.25 * r11);
											//System.out.println(un3);
											int lo111 = 1;
											int un2111 = (int) (Math.random() * (un3111 - lo111)) + lo111;
											System.out.println("monster attacked and indlicated by"+un2111+"damage to you");
											int y111  = y11 - un2111;
											//her.sethp(y);
											System.out.println("your hp: "+y111 +"/100"+" "+" monster hp :"+r111+"/100");
											System.out.println("Special power deactivated");
											
										
										System.out.println("choose a fight option");
										System.out.println("1)" + " " + "attack");
										System.out.println("2)" + " " + "defence");
										int hut  = scan.nextInt();
										if (hut == 1) {
											System.out.println("you choose to attack");
											//int kill1 = scan.nextInt();
											System.out.println("you attacked and infiliated by "+15+"damage the heros");
											int r1111 = r111-15;
											System.out.println("your hp: "+y111 +"/100"+" "+" monster hp :"+r1111+"/100");
											System.out.println("monster attack");
											//Random rand111  = new Random();
											int un31111  =(int) (0.25 * r11);
											//System.out.println(un3);
											int lo1111 = 1;
											int un21111 = (int) (Math.random() * (un31111 - lo1111)) + lo1111;
											System.out.println("monster attacked and indlicated by"+un21111+"damage to you");
											int y1111  = y111 - un21111;
											//her.sethp(y);
											System.out.println("your hp: "+y1111 +"/100"+" "+" monster hp :"+r1111+"/100");
											System.out.println("choose a fight option");
											System.out.println("1)" + " " + "attack");
											System.out.println("2)" + " " + "defence");
											int cut  = scan.nextInt();
											if (cut == 1) {
												System.out.println("you choose to attack");
												//int kill1 = scan.nextInt();
												System.out.println("you attacked and infiliated by "+15+"damage the heros");
												int r11111 = r1111-15;
												System.out.println("your hp: "+y1111 +"/100"+" "+" monster hp :"+r11111+"/100");
												System.out.println("monster attack");
												//Random rand111  = new Random();
												int un311111  =(int) (0.25 * r11);
												//System.out.println(un3);
												int lo11111 = 1;
												int un211111 = (int) (Math.random() * (un311111 - lo11111)) + lo11111;
												System.out.println("monster attacked and indlicated by"+un211111+"damage to you");
												int y11111  = y1111 - un211111;
												//her.sethp(y);
												System.out.println("your hp: "+y11111 +"/100"+" "+" monster hp :"+r11111+"/100");
												System.out.println("choose a fight option");
												System.out.println("1)" + " " + "attack");
												System.out.println("2)" + " " + "defence");
												int yut = scan.nextInt();
												if (yut == 1) {
													System.out.println("you choose to attack");
													//int kill1 = scan.nextInt();
													System.out.println("you attacked and infiliated by "+10+"damage the heros");
													int r111111 = r11111-10;
													System.out.println("your hp: "+y11111 +"/100"+" "+" monster hp :"+r111111+"/100");
													System.out.println("monster attack");
													//Random rand111  = new Random();
													int un3111111  =(int) (0.25 * r11);
													//System.out.println(un3);
													int lo111111 = 1;
													int un2111111 = (int) (Math.random() * (un3111111 - lo111111)) + lo111111;
													System.out.println("monster attacked and indlicated by"+un211111+"damage to you");
													int y111111  = y11111 - un2111111;
													//her.sethp(y);
													System.out.println("your hp: "+y111111 +"/100"+" "+" monster hp :"+r111111+"/100");
													System.out.println("choose a fight option");
													System.out.println("1)" + " " + "attack");
													System.out.println("2)" + " " + "defence");
													int lut  =scan.nextInt();
													if (lut == 1) {
														System.out.println("you choose to attack");
														//int kill1 = scan.nextInt();
														System.out.println("you attacked and infiliated by "+10+"damage the heros");
														int r1111111 = r111111-10;
														System.out.println("your hp: "+y111111 +"/100"+" "+" monster hp :"+r1111111+"/100");
														System.out.println("monster attack");
														//Random rand111  = new Random();
														int un31111111  =(int) (0.25 * r11);
														//System.out.println(un3);
														int lo1111111 = 1;
														int un21111111 = (int) (Math.random() * (un31111111 - lo1111111)) + lo1111111;
														System.out.println("monster attacked and indlicated by"+un211111+"damage to you");
														int y1111111  = y111111 - un21111111;
														//her.sethp(y);
														System.out.println("your hp: "+y1111111 +"/100"+" "+" monster hp :"+r1111111+"/100");
														System.out.println("choose a fight option");
														System.out.println("1)" + " " + "attack");
														System.out.println("2)" + " " + "defence");
														int iut = scan.nextInt();
														if (iut == 1) {
															System.out.println("you choose to attack");
															//int kill1 = scan.nextInt();
															System.out.println("you attacked and infiliated by "+10+"damage the heros");
															int r11111111 = r1111111-10;
															System.out.println("your hp: "+y1111111 +"/100"+" "+" monster hp :"+r11111111+"/100");
			
															if (r11111111 < 0) {
																System.out.println(" monster defeated ");
																System.out.println(" 20 xp awarded ");
																System.out.println("level 2 == :) level up");
																System.out.println(" fight won procedd to next location");
																
															}

														}
													}
												}
											}
											
											
											
										}
										
										}
										
										
									}
								}
								
								
								
								
								

							}
						} else if (ght == 2) {

						} else if (ght == 3) {

						} else if (ght == -1) {
							break;
						}

					}

				}
				if (un == 2) {
					System.out.print("user creation done" + " | ");
					System.out.print("username" + " " + usr + ".");
					System.out.print("hero type " + " " + "thief");
					System.out.print("log into play the game");
					System.out.println("existing");
					main.displaygame();
					int urf = scan.nextInt();
					if (urf == 2) {
						System.out.println("enter a username");
						String ued = scan.next();
						if (ued.matches(usr)) {
							System.out.println("user found....logging in ");
							System.out.println("welcome " + usr);
							System.out.println("you are at the sarting location" + " " + "choodse path");
							
							System.out.println("1)" + " " + "go to location 0");
							System.out.println("2)" + " " + "go to location 3");
							System.out.println("3)" + " " + "go to location 6");
							// System.out.println("4)"+" "+"go to location 1");
							System.out.println("enter -1 to exit");

						} else {
							System.out.println("user not found");
						}
						int ght = scan.nextInt();
						if (ght == 1) {
							System.out.println("");
						} else if (ght == 2) {

						} else if (ght == 3) {

						} else if (ght == -1) {
							break;
						}

					}
				}
			}
			break;
		}

	}
}