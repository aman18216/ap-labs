import java.util.Scanner;
import java.util.ArrayList;
import java.util.Random;

class game{
	private final String username = "";

	public String getUsername() {
		return username;
	}
	public void displaygame() {
		System.out.println("welcome to the  guardians of galaxy");
		System.out.println("choose a option");
		System.out.println("1 )  new user");
		System.out.println("2 ) existing user ");
		System.out.println("3 ) exit");
	}
}
class sidekick{
	protected int xp;
	protected int hp;
	public int getXp(){
		return xp;
	}
	public void setXp(int xp){
		this.xp = xp; 
	}
	public int getHp(){
		return hp;
	}
	public void setHp(int hp){
		this.hp = hp;
	}
	public void attack(){
		
	}
}
class minnions extends sidekick{
	protected int hp;
	protected int xp;
	private int attack =1;
	public int getHp() {
		return hp;
	}
	public void setHp(int hp) {
		this.hp = hp;
	}
	public int getXp() {
		return xp;
	}
	public void setXp(int xp) {
		this.xp = xp;
	}
	public Object clone() throws CloneNotSupportedException{  
		return super.clone();  
	}
	public int getAttack() {
		return attack;
	}
	public void setAttack(int attack) {
		this.attack = attack;
	}  
	
}
class knight extends sidekick{
	protected int xp;
	protected int hp;
	private int attack = 2;
	public int getXp() {
		return xp;
	}
	public void setXp(int xp) {
		this.xp = xp;
	}
	public int getHp() {
		return hp;
	}
	public void setHp(int hp) {
		this.hp = hp;
	}
	public int getAttack() {
		return attack;
	}
	public void setAttack(int attack) {
		this.attack = attack;
	}
	
	
}
class user {
	private String username;

	public user(String username) {
		this.username = username;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	ArrayList<user> user1 = new ArrayList<user>();

	public void adduser(String username) {
		user1.add(new user(username));
	}
}

 class hero {
	protected  int xp;
	protected int hp;
	private final String name;
	private monster Monster;
	//protected int maxdamage;
	//protected int mindamage;
	//protected double hitchance;

	public hero(int xp, int hp, String name) {
		// super(username);
		this.xp = xp;
		this.hp = hp;
		this.name = name;
	}

	public int getXp() {
		return xp;
	}
	public void setXp(int xp){
		this.xp = xp;
	}

	public int getHp() {
		return hp;
	}
	public void setHp(int hp){
		this.hp = hp;
	}

	public String getName() {
		return name;
	}

	public void herostypes() {
		ArrayList<hero> he = new ArrayList<hero>();
		//hero h1 = new hero(100, 0, "warrior");
		//.he.hero h2 = new hero(100, 0, "theif");
		//hero// h3 = new hero(100, 0, "mage");
		//hero h4 = new hero(100, 0, "healer");
		//he.add(h1);
		//he.add(h2);
		//he.add(h3);
		//he.add(h4);
		// System.out.print(h1);
	}
	public void setMonster(monster Monster) {
	    this.Monster = Monster;
	}
	//public void decreasehp(int damage) {
		//this.hp = getHp() - damage;
	//}
	public  void attack(hero mn,monster Monster) {
		
	}

	
	public void defence() {
		
	}
}
abstract class warrorior extends hero{
	private  int defence = 3;
	private int aatack = 10;
	public warrorior(int xp, int hp, String name) {
		super(xp, hp, name);
		// TODO Auto-generated constructor stub
	}
	public void lionfagsttack(){

	}
	
	public int getDefence() {
		return defence;
	}
	public void setDefence(int defence) {
		this.defence = defence;
	}
	public int getAatack() {
		return aatack;
	}
	public void setAatack(int aatack) {
		this.aatack = aatack;
	}
	public void lionfagattack() {
		
	}
	
	
	
}
abstract class theif extends hero{
	private int defence   = 4;
	private int attack  = 6;
	
	public theif(int xp, int hp, String name) {
		super(xp, hp, name);
		// TODO Auto-generated constructor stub
	}

	public int getDefence() {
		return defence;
	}

	public void setDefence(int defence) {
		this.defence = defence;
	}

	public int getAttack() {
		return attack;
	}

	public void setAttack(int attack) {
		this.attack = attack;
	}
	public void lionfagattack() {
		
	}
	
	
}
abstract class mage extends hero{
	private int defence   =5 ;
	private int attack  = 5;
	public mage(int xp, int hp, String name) {
		super(xp, hp, name);
		// TODO Auto-generated constructor stub
	}
	
	public int getDefence() {
		return defence;
	}

	public void setDefence(int defence) {
		this.defence = defence;
	}

	public int getAttack() {
		return attack;
	}

	public void setAttack(int attack) {
		this.attack = attack;
	}

	public void specialaatck(){
		
	}
	public void lionfagattack() {
		
	}
	
}
abstract class healer extends hero{
	private int defence   =4 ;
	private int attack  = 8;
	public healer(int xp, int hp, String name) {
		super(xp, hp, name);
		// TODO Auto-generated constructor stub
	}
	public int getDefence() {
		return defence;
	}
	public void setDefence(int defence) {
		this.defence = defence;
	}
	public int getAttack() {
		return attack;
	}
	public void setAttack(int attack) {
		this.attack = attack;
	}
	public void lionfagattack() {
		
	}
	
	
}

class monster {
	private String name;
	protected int xp;
	protected int hp;

	public monster(String name, int xp, int hp) {
		super();
		this.name = name;
		this.xp = xp;
		this.hp = hp;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getXp() {
		return xp;
	}

	public void setXp(int xp) {
		this.xp = xp;
	}

	public int getHp() {
		return hp;
	}

	public void setHp(int hp) {
		this.hp = hp;
	}
	public void attack() {
		
	}
	ArrayList <monster> mun = new ArrayList<monster>();
	

}
 abstract class goblins extends monster{

	public goblins(String name, int xp, int hp) {
		super(name, xp, hp);
		// TODO Auto-generated constructor stub
	}
	
}
abstract class zombies extends monster{

	public zombies(String name, int xp, int hp) {
		super(name, xp, hp);
		// TODO Auto-generated constructor stub
	}
	
}
abstract class fiends extends monster{

	public fiends(String name, int xp, int hp) {
		super(name, xp, hp);
		// TODO Auto-generated constructor stub
	}
	
}
abstract class lionflag extends monster{

	public lionflag(String name, int xp, int hp) {
		super(name, xp, hp);
		// TODO Auto-generated constructor stub
	}
	
}

public class maingame {
	public static void main(String args[]) throws CloneNotSupportedException {
		Scanner scan = new Scanner(System.in);
		game main = new game();
		user us = new user(null);
		hero her = new hero(0, 0, null);
		minnions mn = new minnions();
		
		main.displaygame();
		for (int i = 0; i < 10; i++) {
			int t = scan.nextInt();
			if (t == 1) {
				System.out.println("enter username");
				String usr = scan.next();
				System.out.println("choose type of heros");
				System.out.println("1)" + " " + "warrior");
				System.out.println("2)" + " " + "thief");
				System.out.println("3)" + " " + "marge");
				System.out.println("4)" + " " + "healer");
				int un = scan.nextInt();
				if (un == 1) {
					System.out.print("user creation done" + " | ");
					System.out.print("username" + " " + usr + ".");
					System.out.print("hero type " + " " + "warrior");
					System.out.print("log into play the game");
					System.out.println("existing");
					main.displaygame();
					int urf = scan.nextInt();
					if (urf == 2) {
						System.out.println("enter a username");
						String ued = scan.next();
						if (ued.matches(usr)) {
							System.out.println("user found....logging in ");
							System.out.println("welcome " + usr);
							System.out.println("you are at the sarting location" + " " + "choodse path");
							Random rand  = new Random();
							int r1 = rand.nextInt(10);
							int r2 = rand.nextInt(10);
							int r3 = rand.nextInt(10);
							System.out.println("1)" + " " + "go to location "+r1);
							System.out.println("2)" + " " + "go to location "+r2);
							System.out.println("3)" + " " + "go to location "+r3);
							// System.out.println("4)"+" "+"go to location 1");
							System.out.println("enter -1 to exit");

						} else {
							System.out.println("user not found");
						}
						int ght = scan.nextInt();
						if (ght == 1) {
							System.out.println("moving to location 0 ");
							System.out.println("fight started . you fighting a level 1 monster");
							System.out.println("choose a fight option");
							System.out.println("1)" + " " + "attack");
							System.out.println("2)" + " " + "defence");
							int uht = scan.nextInt();
							if (uht == 1) {
								System.out.println("you choose to attack");
								//int kill = scan.nextInt();
								System.out.println("you attacked and infiliated by "+"10"+"damage the heros");
								int r = 100-10;
								System.out.println("your hp : 100 /100 "+ " : "+"monster hp :"+ r);
								System.out.println("monster attack");
								Random rand  = new Random();
								int un3  =(int) (0.25 * r);
								//System.out.println(un3);
								int lo = 1;
								int un2 = (int) (Math.random() * (un3 - lo)) + lo;
								System.out.println("monster attacked and indlicated by"+un2+"damage to you");
								int y  = 100 - un2;
								//her.sethp(y);
								System.out.println("your hp: "+y +"/100"+" "+" monster hp :"+r+"/100");
							if (uht == 2) {
									System.out.println("you choose to defence");
									System.out.println("monster attack");
									Random rand2  = new Random();
									int un32  =(int) (0.25 * r);
									//System.out.println(un3);
									int lo2 = 1;
									int un22 = (int) (Math.random() * (un32 - lo2)) + lo2;
									System.out.println("monster attacked and indlicated by"+un2+"damage to you");
									int y2  = (100 - un22) -3;
									//her.sethp(y);
									System.out.println("your hp: "+y2 +"/100"+" "+" monster hp :"+r+"/100");
									
							}
								System.out.println("choose a fight option");
								System.out.println("1)" + " " + "attack");
								System.out.println("2)" + " " + "defence");
								int yu =scan.nextInt();
								if (yu == 1) {
									System.out.println("you choose to attack");
									//int kill1 = scan.nextInt();
									System.out.println("you attacked and infiliated by "+10+"damage the heros");
									int r1 = r-10;
									System.out.println("your hp: "+y +"/100"+" "+" monster hp :"+r1+"/100");
									System.out.println("monster attack");
									@SuppressWarnings("unused")
									Random rand1  = new Random();
									int un31  =(int) (0.25 * r1);
									//System.out.println(un3);
									int lo1 = 1;
									int un21 = (int) (Math.random() * (un31 - lo1)) + lo1;
									System.out.println("monster attacked and indlicated by"+un21+"damage to you");
									int y1  = y - un21;
									//her.sethp(y);
									System.out.println("your hp: "+y1 +"/100"+" "+" monster hp :"+r1+"/100");
									System.out.println("choose a fight option");
									System.out.println("1)" + " " + "attack");
									System.out.println("2)" + " " + "defence");
									int tuf = scan.nextInt();
									if (tuf== 1) {
										System.out.println("you choose to attack");
										//int kill1 = scan.nextInt();
										System.out.println("you attacked and infiliated by "+10+"damage the heros");
										int r11 = r1-10;
										System.out.println("your hp: "+y1 +"/100"+" "+" monster hp :"+r11+"/100");
										System.out.println("monster attack");
										@SuppressWarnings("unused")
										Random rand11  = new Random();
										int un311  =(int) (0.25 * r11);
										//System.out.println(un3);
										int lo11 = 1;
										int un211 = (int) (Math.random() * (un311 - lo11)) + lo11;
										System.out.println("monster attacked and indlicated by"+un211+"damage to you");
										int y11  = y1 - un211;
										//her.sethp(y);
										System.out.println("your hp: "+y11 +"/100"+" "+" monster hp :"+r11+"/100");
										System.out.println("choose a fight option");
										System.out.println("1)" + " " + "attack");
										System.out.println("2)" + " " + "defence");
										System.out.println("3)" + " " + "special attack");
										int  ugh = scan.nextInt();
										if (ugh == 1) {
											
										}
										if (ugh == 2) {
											
										}
										if (ugh == 3) {
											System.out.println("special power activated");
											System.out.println("special power activated ");
											System.out.println("you attacked and infiliated by "+15+"damage the heros");
											int r111 = r11-15;
											System.out.println("your hp: "+y11 +"/100"+" "+" monster hp :"+r111+"/100");
											System.out.println("monster attack");
											Random rand111  = new Random();
											int un3111  =(int) (0.25 * r11);
											//System.out.println(un3);
											int lo111 = 1;
											int un2111 = (int) (Math.random() * (un3111 - lo111)) + lo111;
											System.out.println("monster attacked and indlicated by"+un2111+"damage to you");
											int y111  = y11 - un2111;
											//her.sethp(y);
											System.out.println("your hp: "+y111 +"/100"+" "+" monster hp :"+r111+"/100");
											//System.out.println("Special power deactivated");
											
										
										System.out.println("choose a fight option");
										System.out.println("1)" + " " + "attack");
										System.out.println("2)" + " " + "defence");
										int hut  = scan.nextInt();
										if (hut == 1) {
											System.out.println("you choose to attack");
											//int kill1 = scan.nextInt();
											System.out.println("you attacked and infiliated by "+15+"damage the heros");
											int r1111 = r111-15;
											System.out.println("your hp: "+y111 +"/100"+" "+" monster hp :"+r1111+"/100");
											System.out.println("monster attack");
											//Random rand111  = new Random();
											int un31111  =(int) (0.25 * r11);
											//System.out.println(un3);
											int lo1111 = 1;
											int un21111 = (int) (Math.random() * (un31111 - lo1111)) + lo1111;
											System.out.println("monster attacked and indlicated by"+un21111+"damage to you");
											int y1111  = y111 - un21111;
											//her.sethp(y);
											System.out.println("your hp: "+y1111 +"/100"+" "+" monster hp :"+r1111+"/100");
											System.out.println("choose a fight option");
											System.out.println("1)" + " " + "attack");
											System.out.println("2)" + " " + "defence");
											int cut  = scan.nextInt();
											if (cut == 1) {
												System.out.println("you choose to attack");
												//int kill1 = scan.nextInt();
												System.out.println("you attacked and infiliated by "+15+"damage the heros");
												int r11111 = r1111-15;
												System.out.println("your hp: "+y1111 +"/100"+" "+" monster hp :"+r11111+"/100");
												System.out.println("monster attack");
												//Random rand111  = new Random();
												int un311111  =(int) (0.25 * r11);
												//System.out.println(un3);
												int lo11111 = 1;
												int un211111 = (int) (Math.random() * (un311111 - lo11111)) + lo11111;
												System.out.println("monster attacked and indlicated by"+un211111+"damage to you");
												int y11111  = y1111 - un211111;
												//her.sethp(y);
												System.out.println("your hp: "+y11111 +"/100"+" "+" monster hp :"+r11111+"/100");
												System.out.println("special power deactivated ");
												System.out.println("choose a fight option");
												System.out.println("1)" + " " + "attack");
												System.out.println("2)" + " " + "defence");
												int yut = scan.nextInt();
												if (yut == 1) {
													System.out.println("you choose to attack");
													//int kill1 = scan.nextInt();
													System.out.println("you attacked and infiliated by "+10+"damage the heros");
													int r111111 = r11111-10;
													System.out.println("your hp: "+y11111 +"/100"+" "+" monster hp :"+r111111+"/100");
													System.out.println("monster attack");
													//Random rand111  = new Random();
													int un3111111  =(int) (0.25 * r11);
													//System.out.println(un3);
													int lo111111 = 1;
													int un2111111 = (int) (Math.random() * (un3111111 - lo111111)) + lo111111;
													System.out.println("monster attacked and indlicated by"+un211111+"damage to you");
													int y111111  = y11111 - un2111111;
													//her.sethp(y);
													System.out.println("your hp: "+y111111 +"/100"+" "+" monster hp :"+r111111+"/100");
													System.out.println("choose a fight option");
													System.out.println("1)" + " " + "attack");
													System.out.println("2)" + " " + "defence");
													int lut  =scan.nextInt();
													if (lut == 1) {
														System.out.println("you choose to attack");
														//int kill1 = scan.nextInt();
														System.out.println("you attacked and infiliated by "+10+"damage the heros");
														int r1111111 = r111111-10;
														System.out.println("your hp: "+y111111 +"/100"+" "+" monster hp :"+r1111111+"/100");
														System.out.println("monster attack");
														//Random rand111  = new Random();
														int un31111111  =(int) (0.25 * r11);
														//System.out.println(un3);
														int lo1111111 = 1;
														int un21111111 = (int) (Math.random() * (un31111111 - lo1111111)) + lo1111111;
														System.out.println("monster attacked and indlicated by"+un211111+"damage to you");
														int y1111111  = y111111 - un21111111;
														//her.sethp(y);
														System.out.println("your hp: "+y1111111 +"/100"+" "+" monster hp :"+r1111111+"/100");
														System.out.println("choose a fight option");
														System.out.println("1)" + " " + "attack");
														System.out.println("2)" + " " + "defence");
														int iut = scan.nextInt();
														if (iut == 1) {
															System.out.println("you choose to attack");
															//int kill1 = scan.nextInt();
															System.out.println("you attacked and infiliated by "+10+"damage the heros");
															int r11111111 = r1111111-10;
															System.out.println("your hp: "+y1111111 +"/100"+" "+" monster hp :"+r11111111+"/100");
			
															if (r11111111 < 0) {
																System.out.println(" monster defeated ");
																System.out.println(" 20 xp awarded ");
																//int a = her.setXp(20);
																System.out.println("level 2 == :) level up");
																System.out.println(" fight won procedd to next location");
																
															}

														}
														System.out.println("if you want to buy a sidekick wirte yes or wrte no if wang to upgrade your level");
														String intin = scan.next();
														if (intin.matches("yes")){
															System.out.println("your current xp is"+" "+20);
															System.out.println("1)  if you want to buy a minon");
															System.out.println("2)  if  you want to buy knight");
															int but = scan.nextInt();
															if (but == 1){
																int dut = scan.nextInt();
																System.out.println("xp to be spend "+dut);
																Float gut = scan.nextFloat();
																if (dut == 5){
																	System.out.println("xp of sidekick is "+gut);
																	System.out.println("attack of damage is "+ 1);

																}
																else{
																	if (dut > 5){
																		int v = dut  - 5;
																		int v1 =(int) (v*0.5);
																		int v11 = 1+v1;
																		Random rand9 = new Random();
																		int l1 = rand9.nextInt(10);
																		int l2 = rand9.nextInt(10);
																		int l3 = rand9.nextInt(10);
																		System.out.println("attack of sidekick is"+v11);
																		System.out.println("you are ata location 0");

																		System.out.println("1)" + " " + "go to location "+l1);
																			System.out.println("2)" + " " + "go to location "+l2);
																		System.out.println("3)" + " " + "go to location "+l3);
																		// System.out.println("4)"+" "+"go to location 1");
																		System.out.println("enter -1 to exit");
																		int p = scan.nextInt();
																		if (p == 1){
																			System .out.println("moving to location"+l1);
																			System.out.println("fight started !!!!! you are fighting with level 1 monster");
																			System.out.println("Type yes if you wish to use a sidekick, else type no.");
																			String nq =  scan.next();
																			if (nq.matches("yes")){
																				System.out.println("You have a sidekick Minion with you. Attack of sidekick is"+v11);
																				System.out.println("Press c to use cloning ability. Else press f to move to the fight");
																				String new1 = scan.next();
																				//minnions mn1=(minnions)mn.clone();
																				//minnions mn2=(minnions)mn1.clone();
																				
																				  
																				if (new1.matches("c")){
																					System.out.println("clonning done");
																					System.out.println("choose a fight option");
																					System.out.println("1)" + " " + "attack");
																					System.out.println("2)" + " " + "defence");
																					
																					int new2 = scan.nextInt();
																					System.out.println("you choose to attack");
																					System.out.println("You attacked and inflicted"+10+"damage to the monster.\r\n" + 
																							"Sidekick attacked and inflicted"+v11+"damage to the monster.\r\n" + 
																							"Sidekick attacked and inflicted"+v11+"damage to the monster.\r\n" + 
																							"Sidekick attacked and inflicted"+v11+"damage to the monster.\r\n" + 
																							"Sidekick attacked and inflicted"+v11+"damage to the monster.");
																					System.out.println("Sidekick Hp:100.0/100\r\n" + 
																							"Sidekick Hp:100.0/100\r\n" + 
																							"Sidekick Hp:100.0/100\r\n" + 
																							"Sidekick Hp:100.0/100");
																					int k = 10+4*v11;
																					System.out.println("your hp: "+"100/100"+"    "+"monster hp:"+k +"/100");
																					System.out.println("monster attack");
																					Random rand7 = new Random();
																					int e = rand7.nextInt(20);
																					System.out.println("monster attacked and inflicted by"+e);
																					int t1 = 100 - e ;
																					System.out.println("your hp"+t1+"/100"+"   "+"monster hp :"+k+"/100");
																					double p1 = e* (1.5);
																					System.out.println("Sidekick Hp:"+p1+"/100\r\n" + 
																							"Sidekick Hp:"+p1+"/100\r\n" + 
																							"Sidekick Hp:"+p1+"/100\r\n" + 
																							"Sidekick Hp:"+p1+"/100");
																					System.out.println("choose a fight option");
																					System.out.println("1)" + " " + "attack");
																					System.out.println("2)" + " " + "defence");
																					int nt = scan.nextInt();
																					if (nt == 1)
																					{
																						
																					}
																					else {
																						System.out.println("you choose to defend");
																						System.out.println("monster attack is reduced by 3!");
																						System.out.println("your hp"+t1+"/100"+"   "+"monster hp :"+k+"/100");
																						System.out.println("monster attack");
																						Random rand71 = new Random();
																						int e1 = rand71.nextInt(20);
																						int w= e1 - 3;
																						System.out.println("monster attacked and inflicted by"+w);
																						int b = t1-w;
																						System.out.println("your hp"+b+"/100"+"   "+"monster hp :"+k+"/100");
																						double h =w*1.5;
																						double z = p1 - h; 
																						System.out.println("Sidekick Hp:"+z+"/100\r\n" + 
																								"Sidekick Hp:"+z+"/100\r\n" + 
																								"Sidekick Hp:"+z+"/100\r\n" + 
																								"Sidekick Hp:"+z+"/100");
																						
																						
																						
																						
																						
																						
																						
																						
																						
																						
																					}
																					
																					

																				}
																				else {
																					System.out.println("choose a fight option");
																					System.out.println("1)" + " " + "attack");
																					System.out.println("2)" + " " + "defence");
																				}
																			}
																			

																			

																		}




																	}
																}
															}

														}
														else if (intin.matches("no")){
															int i1 = rand.nextInt(10);
															int i2 = rand.nextInt(10);
															int i3 = rand.nextInt(10);
															System.out.println("1)" + " " + "go to location "+i1);
															System.out.println("2)" + " " + "go to location "+i2);
															System.out.println("3)" + " " + "go to location "+i3);
															int out = scan.nextInt();
															if (out == 1){
																System.out.println("you are at the "+"  "+i1+"  "+"location");


															}

														}

													}
												}
											}
											
											
											
										}
										
										}
										
										
									}
								}
								
								
								
								
								

							}
						} else if (ght == 2) {
							
						} else if (ght == 3) {

						} else if (ght == -1) {
							break;
						}

					}

				}
				//warrior w = new warrior();
				//thief t = new thief();
				//healer h = new healer ();
				//mage m = new mage();
				if (un == 2) {
					System.out.print("user creation done" + " | ");
					System.out.print("username" + " " + usr + ".");
					System.out.print("hero type " + " " + "thief");
					System.out.print("log into play the game");
					System.out.println("existing");
					main.displaygame();
					int urf = scan.nextInt();
					if (urf == 2) {
						System.out.println("enter a username");
						String ued = scan.next();
						if (ued.matches(usr)) {
							System.out.println("user found....logging in ");
							System.out.println("welcome " + usr);
							System.out.println("you are at the sarting location" + " " + "choodse path");
							
							Random rand = new Random();
							int ra1 = rand.nextInt(10);
							int ra = rand.nextInt(10);
							int ra2 = rand.nextInt(10);
							System.out.println("1)" + " " + "go to location "+ra2);
							System.out.println("2)" + " " + "go to location "+ra1);
							System.out.println("3)" + " " + "go to location "+ra);
							// System.out.println("4)"+" "+"go to location 1");
							System.out.println("enter -1 to exit");
							int ght = scan.nextInt();
						if (ght == 1) {

							System.out.println(" you are at "+"location"+" "+ra2);
							System.out.println("fight started . you fighting a level 1 monster");
							System.out.println("choose a fight option");
							System.out.println("1)" + " " + "attack");
							System.out.println("2)" + " " + "defence");
							int uht = scan.nextInt();
							if (uht == 1){
								System.out.println("you choose to attack");

							}

						} else if (ght == 2) {

						} else if (ght == 3) {

						} else if (ght == -1) {
							break;
						}

						} else {
							System.out.println("user not found");
						}

					}
				}
			}
			break;
		}

	}
}