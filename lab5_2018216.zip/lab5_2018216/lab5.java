import java.util.*;

class map{
	 int r1;
	 int r2;
	 int r3;
	 int h1;
	 int us;
	int [] arr = new int[us];
	//arr = new int[us];
	public map(int r1, int r2, int r3, int h1, int us) {
		super();
		this.r1 = r1;
		this.r2 = r2;
		this.r3 = r3;
		this.h1 = h1;
		this.us = us;
		
	for(r1=0;r1>0;r1--) {
		Random rand = new Random();
		int r = rand.nextInt(us);
		arr[r] =10;
	}
	for(r2=0;r2>0;r3--) {
		Random rand1  =new Random();
		int t1 = rand1.nextInt();
		arr[t1] = 11;
	}
	for(r3=0;r3>0;r3--) {
		Random rand2 = new Random();
		int t2 = rand2.nextInt();
		arr[t2] = 12;
	}
	}
}
class Dice 
{
	int dice;
    int roll() 
    {
        dice = (int)(Math.random()*6) + 1;
        return dice;
    }
    int getDice() 
    {
        return dice;
    }
}
class snakebiteexception extends Exception{
	public snakebiteexception(String s){
		super(s);
	}
}
class cricketbiteexception extends Exception{
	public cricketbiteexception(String s) {
		super(s);	
	}
}
class vulturebiteexception extends Exception{
	public vulturebiteexception(String s) {
		super(s);
	}
}
class trampolinexception extends Exception{
	public trampolinexception(String s) {
		super(s);
	}
}
class gameWinnerexception extends Exception{
	public gameWinnerexception(String s) {
		super(s);
	}
}
abstract class tile{
	public void bite(int til) throws snakebiteexception,cricketbiteexception ,vulturebiteexception,trampolinexception{
		til=0;
	}
}
class snake extends tile{
	private int walk;
	Random rand11  = new Random();
	private final int stepback =0;
	
	static final int pick =0;
	public snake(int walk) {
		this.walk =walk;
	}
	@Override
	public void bite(int til)throws snakebiteexception {
		til-=walk;
	}
}
class cricket extends tile{
	private int walk;
	private final int stepback1 =0;
	public cricket(int walk) {
		this.walk = walk;
		
	}
	@Override
	public void bite(int til)throws cricketbiteexception {
		//til-=walk;
	}
}
class vulture extends tile{
	private int walk;
	private final int stepback3 =0;
	public vulture(int walk) {
		this.walk = walk;
		
	}
	@Override
	public void bite(int til)throws vulturebiteexception {
		Random rand1 = new Random();
		til-=walk;
	}
}
class white extends tile{
	private int walk;
	public white(int walk) {
		this.walk = walk;
		
	}
	@Override
	public void bite(int tiles) {
		
	}
}
class trampolin extends tile{
	private int jump;
	public trampolin(int jump) {
		this.jump=jump;
	}
	@Override
	public void bite(int til)throws trampolinexception {
		//til+=jump;
	}
	
}
public class lab5 {
	private static int lengt1;

	//@SuppressWarnings("unused")
	public static void main(String[] args) throws snakebiteexception {
		//@SuppressWarnings("resource")
		Dice d1  = new Dice();
		snake s1 = new snake(0);
		cricket c1 =new cricket(0);
		trampolin te = new trampolin(0);
		vulture v2 = new vulture(0);
		tile mn = new snake(lengt1);
		tile mn1 = new cricket(lengt1);
		tile mn2 = new vulture(lengt1);
		tile mn3 = new trampolin(lengt1);
		Scanner obj  = new Scanner(System.in);
		System.out.println("enter total no of tiles on the tracks (length)");
		//int lengt = obj.nextInt();
		int lengt =0;
		boolean aman  =false;
		while(!aman) {
			try {
				int lengt1 = obj.nextInt();
				aman=true;
				
			}
			catch(InputMismatchException e) {
				System.out.println("invalid input");
				System.out.println("try again");
				obj.nextLine();
			}
			
		}
		System.out.println("setting up your race track");
		Random rand = new Random();
		int r1 = rand.nextInt(10)+1;
		int r2 = rand.nextInt(10)+1;
		int r3 = rand.nextInt(10)+1;
		System.out.println("Danger: There are"+r1+" ,"+r2+", "+r3+"numbers of Snakes, Cricket, and Vultures respectively on your track!");
		int g1 = rand.nextInt(10)+1;
		int g2 = rand.nextInt(10)+1;
		int g3 = rand.nextInt(10)+1;
		System.out.println("Danger: Each Snake, Cricket, and Vultures can throw you back by"+g1+","+g2+","+g3+"number of Tiles respectively!");
		int h1 = rand.nextInt(10)+1;
		System.out.println("Good News: There are"+h1+"  "+"number of Trampolines on your track!");
		int h2 =rand.nextInt(10)+1;
		System.out.println(">>Good News: Each Trampoline can help you advance by" +  h2 + "number of Tiles");
		System.out.println("enter your username");
		boolean aman1 = false;
		while(!aman1) {
			try {
				String a1 = obj.next();
				
				aman1 =true;
			}
			catch(NumberFormatException e) {
				System.out.println("username should be string");
				obj.nextInt();
			}
		}
		String a11 = obj.next();
		System.out.println("Starting the game with"+"  "+a11+"  "+"at Tile-1\r\n" + 
				"Control transferred to Computer for rolling the Dice for Josh\r\n" + 
				"press 1 to start the game\r\n" + 
				"Game Started ======================>");
		int q1 =obj.nextInt();
		//int d= 0;
		int g =0;
		int t1 =0;
		while(true) {
			int d=0;
			int fog = d1.roll();
			//System.out.println(fog);
			int y1 =t1+1;
			int i1 =d+1;
			System.out.println("[ROLL -:"+i1+"]"+a11+" "+"rolled"+"  "+fog+"  "+"in tile"+" "+y1);
			t1++;
			if (i1==1 && fog==1) {
				int i11 = t1+1;
				System.out.println("oops you need to start again");
				System.out.println("[ROLL -:"+i11+"]"+a11+" "+"rolled"+"  "+fog+"  "+"in tile"+" "+y1);
				
			}
			int array[] =new int[lengt1];
			try {
				if (array[fog] == 10) {
					System.out.println("[ROLL -:"+i1+"]"+a11+" "+"rolled"+"  "+fog+"  "+"in tile"+" "+y1);
					System.out.println("Trying to shake the"+t1+"\r\n" + 
							">> Hiss...! I am a Snake, you go back 7 tiles!\r\n" + 
							">>moved to Tile 1 as it can�t go back further");
					s1.bite(i1);
				
				}
				if (array[fog] == 11) {
					System.out.println("[ROLL -:"+i1+"]"+a11+" "+"rolled"+"  "+fog+"  "+"in tile"+" "+y1);
					System.out.println("Trying to shake the Tile-10\r\n" + 
							">> Chirp...! I am a Cricket, you go back 2 tiles!\r\n" + 
							" Josh moved to Tile 8");
					c1.bite(i1);
				}
				if (array[fog] == 12) {
					System.out.println("[ROLL -:"+i1+"]"+a11+" "+"rolled"+"  "+fog+"  "+"in tile"+" "+y1);
					System.out.println("Trying to shake the Tile-14\r\n" + 
							">> Yapping...! I am a Vulture, you go back 1 tiles! // assuming C=1. VultureBiteException thrown\r\n" + 
							">> Josh moved to Tile-13");
					v2.bite(i1);
				}
				//t1.bite(i1);
			}
			catch(snakebiteexception e) {
				System.out.println(e.getClass());
			}
			catch(cricketbiteexception e) {
				System.out.println(e.getClass());
			}
			catch(vulturebiteexception e) {
				System.out.println(e.getClass());
			
			}
			//catch(trampolinexception e) {
				//System.out.println(e.getClass());
			//}
			//catch(gameWinnerexception e) {
				//System.out.println(e.getClass());
			//}
			break;
			
			
		
		
	}
	

}
}


